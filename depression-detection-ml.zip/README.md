# Detecting Signs of Depression from Social Media Texts

## 📖 Project Description
This project aims to detect signs of depression in users based on their social media posts using Machine Learning techniques.

## 🚀 Features
- Text preprocessing (cleaning, tokenization)
- Feature extraction using TF-IDF
- Machine Learning model (Logistic Regression)
- Prediction of depression likelihood

## 🛠️ Tech Stack
- Python
- Scikit-learn
- Pandas
- Numpy

## 📂 Project Structure
```
depression-detection-ml/
│── README.md
│── requirements.txt
│── .gitignore
│── src/
│   ├── preprocessing.py
│   ├── model.py
│── notebooks/
│── data/
│── models/
│── docs/
```

## ▶️ How to Run
```
pip install -r requirements.txt
python src/model.py
```

## 📌 Author
Vignesh S

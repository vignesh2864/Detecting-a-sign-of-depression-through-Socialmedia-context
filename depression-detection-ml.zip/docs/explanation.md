# Explanation

This project uses Natural Language Processing (NLP) to detect depression.

Steps:
1. Collect social media text data
2. Clean and preprocess text
3. Convert text to numerical form using TF-IDF
4. Train machine learning model
5. Predict depression labels

Label:
1 = Depressed
0 = Not Depressed

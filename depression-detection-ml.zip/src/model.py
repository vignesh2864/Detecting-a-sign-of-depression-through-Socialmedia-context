import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from preprocessing import preprocess_data

# Sample dataset
data = {
    'text': [
        'I feel sad and alone',
        'Life is beautiful',
        'I am depressed and tired',
        'I am very happy today'
    ],
    'label': [1, 0, 1, 0]
}

df = pd.DataFrame(data)

df = preprocess_data(df)

vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(df['clean_text'])
y = df['label']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

model = LogisticRegression()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

print(classification_report(y_test, y_pred))

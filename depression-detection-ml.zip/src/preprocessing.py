import re
import pandas as pd

def clean_text(text):
    text = text.lower()
    text = re.sub(r'http\S+', '', text)
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    return text

def preprocess_data(df):
    df['clean_text'] = df['text'].apply(clean_text)
    return df
